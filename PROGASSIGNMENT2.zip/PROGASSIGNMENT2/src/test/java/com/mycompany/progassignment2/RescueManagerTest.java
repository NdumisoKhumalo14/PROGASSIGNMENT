package com.mycompany.progassignment2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RescueManagerTest {

    private RescueManager manager;

    @BeforeEach
    public void setUp() {
        manager = new RescueManager();
    }

    @Test
    public void testInjuredAnimalCost_withoutSurgery() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR001", "Lion Cub", "Lion", "Serengeti", "Ranger A",
                2, 500.0, "Cut paw", 1000.0, false);
        assertEquals(2000.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    public void testInjuredAnimalCost_withSurgery() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR002", "Lion Cub", "Lion", "Serengeti", "Ranger A",
                2, 500.0, "Broken leg", 1000.0, true);
        assertEquals(7000.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    public void testOrphanedAnimalCost_withFosterCare() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR003", "Elephant Calf", "African Elephant", "Kruger", "Ranger B",
                3, 300.0, 6, 400.0, true);
        assertEquals(3800.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    public void testOrphanedAnimalCost_withoutFosterCare() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR004", "Elephant Calf", "African Elephant", "Kruger", "Ranger B",
                3, 300.0, 6, 400.0, false);
        assertEquals(1300.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    public void testEndangeredSpeciesCost_withSpecialistTeam() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR005", "White Rhino", "White Rhino", "Hluhluwe", "Ranger C",
                4, 750.0, "Critically Endangered", 2000.0, true);
        assertEquals(13000.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    public void testInjuredAnimalPriority_surgeryIsCritical() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR006", "Lion Cub", "Lion", "Serengeti", "Ranger A",
                1, 100.0, "Broken leg", 500.0, true);
        assertEquals(RescuePriority.CRITICAL, rescue.determinePriority());
    }

    @Test
    public void testInjuredAnimalPriority_lowVetCostIsMedium() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR007", "Lion Cub", "Lion", "Serengeti", "Ranger A",
                1, 100.0, "Small cut", 500.0, false);
        assertEquals(RescuePriority.MEDIUM, rescue.determinePriority());
    }

    @Test
    public void testOrphanedAnimalPriority_veryYoungIsCritical() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR008", "Elephant Calf", "African Elephant", "Kruger", "Ranger B",
                1, 100.0, 2, 200.0, false);
        assertEquals(RescuePriority.CRITICAL, rescue.determinePriority());
    }

    @Test
    public void testEndangeredSpeciesPriority_defaultsToHigh() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR009", "White Rhino", "White Rhino", "Hluhluwe", "Ranger C",
                1, 100.0, "Endangered", 500.0, false);
        assertEquals(RescuePriority.HIGH, rescue.determinePriority());
    }

    @Test
    public void testStartRescue_updatesStatus() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR010", "Lion Cub", "Lion", "Serengeti", "Ranger A",
                1, 100.0, "Cut paw", 200.0, false);
        assertEquals(RescueStatus.REPORTED, rescue.getStatus());
        rescue.startRescue();
        assertEquals(RescueStatus.RESCUE_IN_PROGRESS, rescue.getStatus());
    }

    @Test
    public void testCompleteRescue_updatesStatus() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR011", "Lion Cub", "Lion", "Serengeti", "Ranger A",
                1, 100.0, "Cut paw", 200.0, false);
        rescue.startRescue();
        rescue.completeRescue();
        assertEquals(RescueStatus.COMPLETED, rescue.getStatus());
    }

    @Test
    public void testManagerUpdateStatus_existingCase() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR012", "Lion Cub", "Lion", "Serengeti", "Ranger A",
                1, 100.0, "Cut paw", 200.0, false);
        manager.addCase(rescue);
        boolean updated = manager.updateStatus("WR012", RescueStatus.UNDER_OBSERVATION);
        assertTrue(updated);
        assertEquals(RescueStatus.UNDER_OBSERVATION, manager.searchById("WR012").getStatus());
    }

    @Test
    public void testManagerUpdateStatus_unknownCaseReturnsFalse() {
        boolean updated = manager.updateStatus("DOES-NOT-EXIST", RescueStatus.COMPLETED);
        assertFalse(updated);
    }

    @Test
    public void testSearchById_found() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR013", "Elephant Calf", "African Elephant", "Kruger", "Ranger B",
                1, 100.0, 5, 150.0, false);
        manager.addCase(rescue);
        RescueCase found = manager.searchById("WR013");
        assertNotNull(found);
        assertEquals("WR013", found.getCaseId());
    }

    @Test
    public void testSearchById_notFoundReturnsNull() {
        RescueCase found = manager.searchById("NOT-A-REAL-ID");
        assertNull(found);
    }

    @Test
    public void testAddCase_duplicateIdThrowsException() {
        OrphanedAnimalRescue first = new OrphanedAnimalRescue(
                "WR014", "Elephant Calf", "African Elephant", "Kruger", "Ranger B",
                1, 100.0, 5, 150.0, false);
        OrphanedAnimalRescue duplicate = new OrphanedAnimalRescue(
                "WR014", "Another Calf", "African Elephant", "Kruger", "Ranger B",
                1, 100.0, 5, 150.0, false);
        manager.addCase(first);
        IllegalArgumentException assertThrows = assertThrows(IllegalArgumentException.class, () -> manager.addCase(duplicate));
    }

    @Test
    public void testAddCase_duplicateIdIsCaseInsensitive() {
        OrphanedAnimalRescue first = new OrphanedAnimalRescue(
                "wr015", "Elephant Calf", "African Elephant", "Kruger", "Ranger B",
                1, 100.0, 5, 150.0, false);
        manager.addCase(first);
    }
}