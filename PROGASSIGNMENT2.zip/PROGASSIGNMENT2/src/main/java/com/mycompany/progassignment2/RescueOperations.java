package com.mycompany.progassignment2;

public interface RescueOperations {

    void startRescue();

    void completeRescue();

    String generateSummary();
}