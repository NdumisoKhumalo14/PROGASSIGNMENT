package com.mycompany.progassignment2;

public abstract class RescueCase implements RescueOperations {

    private String caseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private RescueStatus status;

    public RescueCase(String caseId, String animalName, String species,
                       String rescueLocation, String assignedRanger,
                       int numberOfRescueDays, double dailyCareCost) {
        setCaseId(caseId);
        setAnimalName(animalName);
        setSpecies(species);
        setRescueLocation(rescueLocation);
        setAssignedRanger(assignedRanger);
        setNumberOfRescueDays(numberOfRescueDays);
        setDailyCareCost(dailyCareCost);
        this.status = RescueStatus.REPORTED;
    }

    public String getCaseId() {
        return caseId;
    }

    private void setCaseId(String caseId) {
        if (caseId == null || caseId.trim().isEmpty()) {
            throw new IllegalArgumentException("Rescue Case ID cannot be blank.");
        }
        this.caseId = caseId.trim();
    }

    public String getAnimalName() {
        return animalName;
    }

    private void setAnimalName(String animalName) {
        if (animalName == null || animalName.trim().isEmpty()) {
            throw new IllegalArgumentException("Animal name cannot be blank.");
        }
        this.animalName = animalName.trim();
    }

    public String getSpecies() {
        return species;
    }

    private void setSpecies(String species) {
        if (species == null || species.trim().isEmpty()) {
            throw new IllegalArgumentException("Species cannot be blank.");
        }
        this.species = species.trim();
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    private void setRescueLocation(String rescueLocation) {
        if (rescueLocation == null || rescueLocation.trim().isEmpty()) {
            throw new IllegalArgumentException("Rescue location cannot be blank.");
        }
        this.rescueLocation = rescueLocation.trim();
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    private void setAssignedRanger(String assignedRanger) {
        if (assignedRanger == null || assignedRanger.trim().isEmpty()) {
            throw new IllegalArgumentException("Assigned ranger cannot be blank.");
        }
        this.assignedRanger = assignedRanger.trim();
    }

    public int getNumberOfRescueDays() {
        return numberOfRescueDays;
    }

    private void setNumberOfRescueDays(int numberOfRescueDays) {
        if (numberOfRescueDays <= 0) {
            throw new IllegalArgumentException("Number of rescue days must be greater than zero.");
        }
        this.numberOfRescueDays = numberOfRescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    private void setDailyCareCost(double dailyCareCost) {
        if (dailyCareCost <= 0) {
            throw new IllegalArgumentException("Daily care cost must be greater than zero.");
        }
        this.dailyCareCost = dailyCareCost;
    }

    public RescueStatus getStatus() {
        return status;
    }

    public void setStatus(RescueStatus status) {
        if (status == null) {
            throw new IllegalArgumentException("Status cannot be null.");
        }
        this.status = status;
    }

    protected double getBaseCost() {
        return dailyCareCost * numberOfRescueDays;
    }

    public abstract double calculateTotalCost();

    public abstract RescuePriority determinePriority();

    public abstract String getRescueType();

    public abstract void displaySpecificDetails();

    @Override
    public void startRescue() {
        this.status = RescueStatus.RESCUE_IN_PROGRESS;
    }

    @Override
    public void completeRescue() {
        this.status = RescueStatus.COMPLETED;
    }

    @Override
    public String generateSummary() {
        return String.format(
                "Case ID        : %s%n" +
                "Type           : %s%n" +
                "Species        : %s%n" +
                "Assigned Ranger: %s%n" +
                "Priority       : %s%n" +
                "Status         : %s%n" +
                "Total Cost     : R%.2f",
                caseId, getRescueType(), species, assignedRanger,
                determinePriority(), status, calculateTotalCost());
    }

    @Override
    public String toString() {
        return String.format("[%s] %s (%s) - %s - %s", caseId, animalName, species,
                getRescueType(), status);
    }
}