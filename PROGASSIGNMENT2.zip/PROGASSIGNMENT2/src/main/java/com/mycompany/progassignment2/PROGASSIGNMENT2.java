package com.mycompany.progassignment2;

import java.util.Scanner;

public class PROGASSIGNMENT2 {

    private static final Scanner scanner = new Scanner(System.in);
    private static final RescueManager manager = new RescueManager();

    public static void main(String[] args) {
        try (scanner) {
            boolean running = true;
            
            while (running) {
                printMenu();
                int choice = readMenuChoice(1, 6);
                
                switch (choice) {
                    case 1 -> createRescueCase();
                    case 2 -> searchRescueCase();
                    case 3 -> updateRescueStatus();
                    case 4 -> displayAllRescueCases();
                    case 5 -> {
                        System.out.println();
                        System.out.println(manager.generateReport());
                    }
                    case 6 -> {
                        running = false;
                        System.out.println("Goodbye! Thank you for using the Wildlife Rescue Operations System.");
                    }
                    default -> {
                    }
                }
            }
        }
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("===================================");
        System.out.println("   WILDLIFE RESCUE OPERATIONS SYSTEM");
        System.out.println("===================================");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Rescue Report");
        System.out.println("6. Exit");
        System.out.print("Select an option: ");
    }

    private static void createRescueCase() {
        System.out.println();
        System.out.println("--- Create Rescue Case ---");

        String caseId = readUniqueCaseId();
        String animalName = readNonBlank("Animal Name: ");
        String species = readNonBlank("Species: ");
        String rescueLocation = readNonBlank("Rescue Location: ");
        String assignedRanger = readNonBlank("Assigned Ranger: ");
        int numberOfRescueDays = readPositiveInt("Number of Rescue Days: ");
        double dailyCareCost = readPositiveDouble("Daily Care Cost (R): ");

        System.out.println("Select rescue case type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");
        int typeChoice = readMenuChoice(1, 3);

        RescueCase newCase;
        switch (typeChoice) {
            case 1 ->  {
                String injuryDescription = readNonBlank("Injury Description: ");
                double vetCost = readNonNegativeDouble("Veterinary Treatment Cost (R): ");
                boolean surgeryRequired = readYesNo("Surgery Required? (y/n): ");
                newCase = new InjuredAnimalRescue(caseId, animalName, species, rescueLocation,
                        assignedRanger, numberOfRescueDays, dailyCareCost,
                        injuryDescription, vetCost, surgeryRequired);
            }
            case 2 ->  {
                int ageMonths = readPositiveInt("Estimated Age (Months): ");
                double feedingCost = readNonNegativeDouble("Feeding Cost (R): ");
                boolean fosterCareRequired = readYesNo("Foster Care Required? (y/n): ");
                newCase = new OrphanedAnimalRescue(caseId, animalName, species, rescueLocation,
                        assignedRanger, numberOfRescueDays, dailyCareCost,
                        ageMonths, feedingCost, fosterCareRequired);
            }
            default ->  {
                String classification = readNonBlank("Conservation Classification: ");
                double securityCost = readNonNegativeDouble("Security Cost (R): ");
                boolean specialistRequired = readYesNo("Specialist Team Required? (y/n): ");
                newCase = new EndangeredSpeciesRescue(caseId, animalName, species, rescueLocation,
                        assignedRanger, numberOfRescueDays, dailyCareCost,
                        classification, securityCost, specialistRequired);
            }
        }
        manager.addCase(newCase);
        System.out.println();
        System.out.println("Rescue case created successfully.");
        System.out.println(newCase.generateSummary());
    }
    private static void searchRescueCase() {
        System.out.println();
        System.out.println("--- Search Rescue Case ---");
        System.out.print("Enter Rescue Case ID: ");
        String caseId = scanner.nextLine();

        RescueCase found = manager.searchById(caseId);
        if (found == null) {
            System.out.println("No rescue case found with ID '" + caseId + "'.");
        } else {
            System.out.println();
            System.out.println(found.generateSummary());
            System.out.println();
            found.displaySpecificDetails();
        }
    }
    private static void updateRescueStatus() {
        System.out.println();
        System.out.println("--- Update Rescue Status ---");
        System.out.print("Enter Rescue Case ID: ");
        String caseId = scanner.nextLine();

        RescueCase found = manager.searchById(caseId);
        if (found == null) {
            System.out.println("No rescue case found with ID '" + caseId + "'.");
            return;
        }

        System.out.println("Current status: " + found.getStatus());
        System.out.println("1. Start Rescue Operation");
        System.out.println("2. Complete Rescue Operation");
        System.out.println("3. Set to Under Observation");
        System.out.println("4. Cancel");
        int choice = readMenuChoice(1, 4);

        switch (choice) {
            case 1 -> {
                found.startRescue();
                System.out.println("Rescue started.");
            }
            case 2 -> {
                found.completeRescue();
                System.out.println("Rescue completed.");
            }
            case 3 -> {
                found.setStatus(RescueStatus.UNDER_OBSERVATION);
                System.out.println("Status set to Under Observation.");
            }
            default -> {
                System.out.println("Update cancelled.");
                return;
            }
        }

        System.out.println();
        System.out.println(found.generateSummary());
    }

    private static void displayAllRescueCases() {
        System.out.println();
        System.out.println("--- All Rescue Cases ---");
        if (manager.getAllCases().isEmpty()) {
            System.out.println("No rescue cases have been recorded yet.");
            return;
        }
        for (RescueCase rescueCase : manager.getAllCases()) {
            System.out.println(rescueCase);
        }
    }
    private static int readMenuChoice(int min, int max) {
        while (true) {
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.printf("Please enter a number between %d and %d: ", min, max);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Please enter a number: ");
            }
        }
    }

    private static String readNonBlank(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine();
            if (input != null && !input.trim().isEmpty()) {
                return input.trim();
            }
            System.out.println("This field cannot be blank.");
        }
    }

    private static String readUniqueCaseId() {
        while (true) {
            String caseId = readNonBlank("Rescue Case ID: ");
            if (manager.isDuplicateId(caseId)) {
                System.out.println("A rescue case with ID '" + caseId + "' already exists. Please use a different ID.");
                continue;
            }
            return caseId;
        }
    }

    private static int readPositiveInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value > 0) {
                    return value;
                }
                System.out.println("Please enter a whole number greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Please try again.");
            }
        }
    }

    private static double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                double value = Double.parseDouble(input);
                if (value > 0) {
                    return value;
                }
                System.out.println("Please enter a number greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Please try again.");
            }
        }
    }
    private static double readNonNegativeDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                double value = Double.parseDouble(input);
                if (value >= 0) {
                    return value;
                }
                System.out.println("Please enter a number that is zero or greater.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Please try again.");
            }
        }
    }
   
    private static boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim().toLowerCase();
            if (input.equals("y") || input.equals("yes")) {
                return true;
            }
            if (input.equals("n") || input.equals("no")) {
                return false;
            }
            System.out.println("Please answer 'y' or 'n'.");
        }
    }
}