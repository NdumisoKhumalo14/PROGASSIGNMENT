package com.mycompany.progassignment2;

public class InjuredAnimalRescue extends RescueCase {

    private static final double SURGERY_SURCHARGE = 5000.0;
    private static final double HIGH_VET_COST_THRESHOLD = 3000.0;

    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    public InjuredAnimalRescue(String caseId, String animalName, String species,
                                String rescueLocation, String assignedRanger,
                                int numberOfRescueDays, double dailyCareCost,
                                String injuryDescription, double veterinaryTreatmentCost,
                                boolean surgeryRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger,
                numberOfRescueDays, dailyCareCost);
        setInjuryDescription(injuryDescription);
        setVeterinaryTreatmentCost(veterinaryTreatmentCost);
        this.surgeryRequired = surgeryRequired;
    }

    public String getInjuryDescription() {
        return injuryDescription;
    }

    private void setInjuryDescription(String injuryDescription) {
        if (injuryDescription == null || injuryDescription.trim().isEmpty()) {
            throw new IllegalArgumentException("Injury description cannot be blank.");
        }
        this.injuryDescription = injuryDescription.trim();
    }

    public double getVeterinaryTreatmentCost() {
        return veterinaryTreatmentCost;
    }

    private void setVeterinaryTreatmentCost(double veterinaryTreatmentCost) {
        if (veterinaryTreatmentCost < 0) {
            throw new IllegalArgumentException("Veterinary treatment cost cannot be negative.");
        }
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
    }

    public boolean isSurgeryRequired() {
        return surgeryRequired;
    }

    public void setSurgeryRequired(boolean surgeryRequired) {
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = getBaseCost() + veterinaryTreatmentCost;
        if (surgeryRequired) {
            total += SURGERY_SURCHARGE;
        }
        return total;
    }

    @Override
    public RescuePriority determinePriority() {
        if (surgeryRequired) {
            return RescuePriority.CRITICAL;
        } else if (veterinaryTreatmentCost > HIGH_VET_COST_THRESHOLD) {
            return RescuePriority.HIGH;
        } else {
            return RescuePriority.MEDIUM;
        }
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    @Override
    public void displaySpecificDetails() {
        System.out.println("Injury Description   : " + injuryDescription);
        System.out.printf("Veterinary Treatment  : R%.2f%n", veterinaryTreatmentCost);
        System.out.println("Surgery Required      : " + (surgeryRequired ? "Yes" : "No"));
    }
}