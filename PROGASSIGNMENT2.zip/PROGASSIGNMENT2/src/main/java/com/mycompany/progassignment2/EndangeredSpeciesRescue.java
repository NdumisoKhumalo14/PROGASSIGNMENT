package com.mycompany.progassignment2;

public class EndangeredSpeciesRescue extends RescueCase {

    private static final double SPECIALIST_TEAM_SURCHARGE = 8000.0;

    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(String caseId, String animalName, String species,
                                    String rescueLocation, String assignedRanger,
                                    int numberOfRescueDays, double dailyCareCost,
                                    String conservationClassification, double securityCost,
                                    boolean specialistTeamRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger,
                numberOfRescueDays, dailyCareCost);
        setConservationClassification(conservationClassification);
        setSecurityCost(securityCost);
        this.specialistTeamRequired = specialistTeamRequired;
    }

    public String getConservationClassification() {
        return conservationClassification;
    }

    private void setConservationClassification(String conservationClassification) {
        if (conservationClassification == null || conservationClassification.trim().isEmpty()) {
            throw new IllegalArgumentException("Conservation classification cannot be blank.");
        }
        this.conservationClassification = conservationClassification.trim();
    }

    public double getSecurityCost() {
        return securityCost;
    }

    private void setSecurityCost(double securityCost) {
        if (securityCost < 0) {
            throw new IllegalArgumentException("Security cost cannot be negative.");
        }
        this.securityCost = securityCost;
    }

    public boolean isSpecialistTeamRequired() {
        return specialistTeamRequired;
    }

    public void setSpecialistTeamRequired(boolean specialistTeamRequired) {
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = getBaseCost() + securityCost;
        if (specialistTeamRequired) {
            total += SPECIALIST_TEAM_SURCHARGE;
        }
        return total;
    }

    @Override
    public RescuePriority determinePriority() {
        return specialistTeamRequired ? RescuePriority.CRITICAL : RescuePriority.HIGH;
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    @Override
    public void displaySpecificDetails() {
        System.out.println("Conservation Class    : " + conservationClassification);
        System.out.printf("Security Cost         : R%.2f%n", securityCost);
        System.out.println("Specialist Team Req.  : " + (specialistTeamRequired ? "Yes" : "No"));
    }
}