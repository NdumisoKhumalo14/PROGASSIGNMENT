package com.mycompany.progassignment2;

public enum RescuePriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}