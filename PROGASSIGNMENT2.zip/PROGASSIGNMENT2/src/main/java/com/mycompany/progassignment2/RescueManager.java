package com.mycompany.progassignment2;

import java.util.ArrayList;
import java.util.List;

public class RescueManager {

    private final List<RescueCase> rescueCases = new ArrayList<>();

    public void addCase(RescueCase newCase) {
        if (isDuplicateId(newCase.getCaseId())) {
            throw new IllegalArgumentException(
                    "A rescue case with ID '" + newCase.getCaseId() + "' already exists.");
        }
        rescueCases.add(newCase);
    }

    public boolean isDuplicateId(String caseId) {
        return searchById(caseId) != null;
    }

    public RescueCase searchById(String caseId) {
        if (caseId == null) {
            return null;
        }
        for (RescueCase rescueCase : rescueCases) {
            if (rescueCase.getCaseId().equalsIgnoreCase(caseId.trim())) {
                return rescueCase;
            }
        }
        return null;
    }

    public boolean updateStatus(String caseId, RescueStatus newStatus) {
        RescueCase rescueCase = searchById(caseId);
        if (rescueCase == null) {
            return false;
        }
        rescueCase.setStatus(newStatus);
        return true;
    }

    public List<RescueCase> getAllCases() {
        return rescueCases;
    }

    public int getTotalCaseCount() {
        return rescueCases.size();
    }

    public double getTotalEstimatedCost() {
        double total = 0;
        for (RescueCase rescueCase : rescueCases) {
            total += rescueCase.calculateTotalCost();
        }
        return total;
    }

    public String generateReport() {
        StringBuilder report = new StringBuilder();
        report.append("=======================================\n");
        report.append("         WILDLIFE RESCUE REPORT\n");
        report.append("=========================================\n\n");

        if (rescueCases.isEmpty()) {
            report.append("No rescue cases have been recorded yet.\n");
        } else {
            for (RescueCase rescueCase : rescueCases) {
                report.append(String.format("Case ID        : %s%n", rescueCase.getCaseId()));
                report.append(String.format("Type           : %s%n", rescueCase.getRescueType()));
                report.append(String.format("Species        : %s%n", rescueCase.getSpecies()));
                report.append(String.format("Location       : %s%n", rescueCase.getRescueLocation()));
                report.append(String.format("Assigned Ranger: %s%n", rescueCase.getAssignedRanger()));
                report.append(String.format("Priority       : %s%n", rescueCase.determinePriority()));
                report.append(String.format("Status         : %s%n", rescueCase.getStatus()));
                report.append(String.format("Total Cost     : R%.2f%n", rescueCase.calculateTotalCost()));
                report.append("--------------------------------------\n\n");
            }
        }

        report.append("=====================================\n");
        report.append(String.format("Total Rescue Cases : %d%n", getTotalCaseCount()));
        report.append(String.format("Total Rescue Cost  : R%.2f%n", getTotalEstimatedCost()));
        report.append("=====================================\n");

        return report.toString();
    }
}