package com.mycompany.progassignment2;

public enum RescueStatus {
    REPORTED("Reported"),
    RESCUE_IN_PROGRESS("Rescue in Progress"),
    UNDER_OBSERVATION("Under Observation"),
    COMPLETED("Completed");

    private final String label;

    RescueStatus(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}