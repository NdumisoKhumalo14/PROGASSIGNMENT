package com.mycompany.progassignment2;

public class OrphanedAnimalRescue extends RescueCase {

    private static final double FOSTER_CARE_SURCHARGE = 2500.0;
    private static final int CRITICAL_AGE_MONTHS = 3;

    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedAnimalRescue(String caseId, String animalName, String species,
                                 String rescueLocation, String assignedRanger,
                                 int numberOfRescueDays, double dailyCareCost,
                                 int estimatedAgeMonths, double feedingCost,
                                 boolean fosterCareRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger,
                numberOfRescueDays, dailyCareCost);
        setEstimatedAgeMonths(estimatedAgeMonths);
        setFeedingCost(feedingCost);
        this.fosterCareRequired = fosterCareRequired;
    }

    public int getEstimatedAgeMonths() {
        return estimatedAgeMonths;
    }

    private void setEstimatedAgeMonths(int estimatedAgeMonths) {
        if (estimatedAgeMonths <= 0) {
            throw new IllegalArgumentException("Estimated age must be greater than zero.");
        }
        this.estimatedAgeMonths = estimatedAgeMonths;
    }

    public double getFeedingCost() {
        return feedingCost;
    }

    private void setFeedingCost(double feedingCost) {
        if (feedingCost < 0) {
            throw new IllegalArgumentException("Feeding cost cannot be negative.");
        }
        this.feedingCost = feedingCost;
    }
    public boolean isFosterCareRequired() {
        return fosterCareRequired;
    }
    public void setFosterCareRequired(boolean fosterCareRequired) {
        this.fosterCareRequired = fosterCareRequired;
    }
    @Override
    public double calculateTotalCost() {
        double total = getBaseCost() + feedingCost;
        if (fosterCareRequired) {
            total += FOSTER_CARE_SURCHARGE;
        }
        return total;
    }
    @Override
    public RescuePriority determinePriority() {
        if (estimatedAgeMonths <= CRITICAL_AGE_MONTHS) {
            return RescuePriority.CRITICAL;
        } else if (fosterCareRequired) {
            return RescuePriority.HIGH;
        } else {
            return RescuePriority.MEDIUM;
        }
    }
    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }
    @Override
    public void displaySpecificDetails() {
        System.out.println("Estimated Age (Months): " + estimatedAgeMonths);
        System.out.printf("Feeding Cost          : R%.2f%n", feedingCost);
        System.out.println("Foster Care Required  : " + (fosterCareRequired ? "Yes" : "No"));
    }
}